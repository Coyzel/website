<?php

$lkod=$_POST['lkod'] ;
$lmevsim=$_POST['lmevsim'] ;
$lmarka=$_POST['lmarka'] ;
$lebat=$_POST['lebat'] ;
$lmodel=$_POST['lmodel'] ;

$baglan=mysqli_connect("localhost","root","","otolastikdunyasi");

mysqli_set_charset($baglan, "utf8");

$sql = "UPDATE lastik SET lkod='$lkod',lmevsim='$lmevsim',lmarka='$lmarka',
lebat='$lebat',lmodel='$lmodel' where lkod='$lkod' ";

$sonuc= mysqli_query($baglan,$sql);

if($sonuc>0) 
{ 
    echo "<script type='text/javascript'>";
    echo "alert('LASTİK BAŞARIYLA GÜNCELLENDİ');";
    echo "window.location = 'anasayfa.html';"; 
    echo "</script>";
}
else{
    echo "<script type='text/javascript'>";
    echo "alert('LASTİK KAYIT EDİLEMEDİ');";
    echo "window.location = 'guncelle.php';"; 
    echo "</script>";
}

?>