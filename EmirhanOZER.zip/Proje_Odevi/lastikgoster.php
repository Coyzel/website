<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lastik Goster</title>

    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        td {
            border: 1px solid #dddddd;
            padding: 10px;
            text-align: center;
        }
        
        h3{
            text-align: center;
            font-size: 25px;
        }
        
    </style>


</head>
<body>



    

<?php

$baglan=mysqli_connect("localhost","root","","otolastikdunyasi");

if (!$baglan) {
    die("Bağlantı sağlanamadı: ".mysqli_connect_error());
}

echo"<h3>BÜTÜN LASTİKLER</h3>";

$sonuc=mysqli_query($baglan,"select * from lastik");
mysqli_set_charset($baglan, "utf8");

echo '<table border="0" width="1350">';
   echo '<tr>';
   echo "<th width='7%'>Lastik Kodu</td>";
   echo '<th width="7%">Lastik Mevsimi</th>';
   echo '<th width="7%">Lastik Markası</th>';
   echo '<th width="7%">Lastik Ebatı</th>';
   echo '<th width="7%">Lastik Modeli</th>';
   echo '</tr>';
   echo '</table>';  

   while($satir=mysqli_fetch_array($sonuc))
   {
      echo '<table border="0" width="1350" style="text-align: center; ">';
      echo '<tr>';
      echo '<td width="7%">'.$satir['lkod'].'</td>';
      echo '<td width="7%">'.$satir['lmevsim'].'</td>';
      echo '<td width="7%">'.$satir['lmarka'].'</td>';
      echo '<td width="7%">'.$satir['lebat'].'</td>';
      echo '<td width="7%">'.$satir['lmodel'].'</td>'; 
      echo '</tr>';
      echo '</table>';  
      echo"<hr>";
   }
   mysqli_close($baglan);




?>


   <a href="anasayfa.html">
   <button style="background-color: blue; color: white">Ana Sayfa</button>
   </a>

</body>
</html>



