<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>giris</title>
</head>
<body>
    
<?php

$lkod=$_POST['lkod'] ;
$lmevsim=$_POST['lmevsim'] ;
$lmarka=$_POST['lmarka'] ;
$lebat=$_POST['lebat'] ;
$lmodel=$_POST['lmodel'] ;

$baglan=mysqli_connect("localhost","root","","otolastikdunyasi");

mysqli_set_charset($baglan, "utf8");

            

$girisyap="INSERT INTO lastik(lkod, lmevsim, lmarka, lebat, lmodel) VALUES ('$lkod','$lmevsim','$lmarka','$lebat','$lmodel')";

$sonuc=mysqli_query($baglan, $girisyap);

if ($sonuc==0){
    echo "Eklenemedi, Bilgileri kontrol ediniz";
}
else{

   echo "<script type='text/javascript'>";
   echo "alert('KAYIT BAŞARIYLA EKLENDİ');";
   echo "window.location = 'anasayfa.html';"; 
   echo "</script>";
}



?>


</body>
</html>