-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 31 May 2024, 15:17:00
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `otolastikdunyasi`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `lastik`
--

CREATE TABLE `lastik` (
  `lkod` int(15) NOT NULL,
  `lmevsim` varchar(15) NOT NULL,
  `lmarka` varchar(15) NOT NULL,
  `lebat` text NOT NULL,
  `lmodel` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `lastik`
--

INSERT INTO `lastik` (`lkod`, `lmevsim`, `lmarka`, `lebat`, `lmodel`) VALUES
(101, 'Yaz', 'Continental', '185/65R 15 88T', 'UltraContact'),
(102, 'Kış', 'Continental', '185/65R 15 88T', 'WinterContact TS 870'),
(103, '4 Mevsim', 'Continental', '185/65R 15 88T', 'AllSeasonsContact'),
(201, 'Yaz', 'Good Year', '205/55R 16 91V', 'Eagle Sport 2'),
(202, 'Kış', 'Good Year', '205/55R 16 91V', 'UltraGrip 8'),
(203, '4 Mevsim', 'Good Year', '205/55R 16 91V', 'Vector 4Seasons Gen-3'),
(301, 'Yaz', 'Bridgestone', '245/45R 17 99Y XL', 'Turanza 6'),
(302, 'Kış', 'Bridgestone', '245/45R 17 99Y XL', 'Blizzak'),
(303, '4 Mevsim', 'Bridgestone', '245/45R 17 99Y XL', 'Weather Controlv'),
(401, 'Yaz', 'Michelin', '225/40R 18 92Y XL', 'Primacy 4+'),
(402, 'Kış', 'Michelin', '225/40R 18 92Y XL', 'Pilot Alpin 5'),
(403, '4 Mevsim', 'Michelin', '225/40R 18 92Y XL', 'Cross Climate 2');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `lastik`
--
ALTER TABLE `lastik`
  ADD PRIMARY KEY (`lkod`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `lastik`
--
ALTER TABLE `lastik`
  MODIFY `lkod` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7778;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
