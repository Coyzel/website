<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lastik Bilgi Güncelle</title>

    <style>

body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content:flex-start;
            
        }

        .Header{
            display: block;
            background-color: rgb(255, 251, 3);
            color: rgb(25, 30, 184);
            text-align: center;
            font-size: 20px;
        }

        .Menu{
        position: relative;
        background-color: rgb(25, 30, 184);            
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100px;
        font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
        font-size: 30px;
        
        }

    .nav-pills{
        display: flex;
        padding: 0;
        margin: 0;
        align-items: center;
        
        
    }

    .nav-item{
        margin-right: 50px;
        align-items: center;
        
    }

    .nav-link{
        text-decoration: none;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        color: rgb(255, 251, 3);   
    }

    img{
        width: 50px;
        height: 50px; 
        border-radius: 50%;
    }
    

    .sidebar {
    width: 250px;
    height: 100vh; 
    background-color: #333;
    color: white;
    padding: 15px;
    box-sizing: border-box;
    position: fixed; 
    left: 0;
    top: 201px;
}

.sidebar h2 {
    text-align: center;
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar ul li {
    margin: 15px 0;
}

.sidebar ul li a {
    color: white;
    text-decoration: none;
    display: block;
    padding: 10px;
    transition: background-color 0.3s;
}

.sidebar ul li a:hover {
    background-color: #575757;
}

.adres {
    margin-left: 250px; 
    padding: 20px;
    box-sizing: border-box;
    
}

.content {
            margin-left: 250px;
            padding: 20px;
            box-sizing: border-box;
            display: flex;
        }

.content .table-container,
.content .adres {
        margin-right: 20px;
        }

.content .table-container{
    
    padding: 5px; 
    

}

.content .table-container table{
    
    border-spacing: 35px;
}

    </style>


</head>
<body>
    
    <div class="Header">
        <h1>OTO LASTİK DÜNYASI</h1> 
        
 </div>


 
 <div class="Menu">
         <ul class="nav-pills" style="list-style-type: none;">
             <li class="nav-item">
                 <a href="anasayfa.html" class="nav-link">
                     <img src="images/ana_sayfa_fotograf.png" alt="">Ana Sayfa
                 </a>
                 
             </li>
             <li class="nav-item">
                 <a href="lastik.html" class="nav-link">
                     <img src="images/giriş_fotoğraf.png" alt="">Lastik Bilgi Giriş
                 </a>
                 
             </li>
             <li class="nav-item">
                 <a href="guncelle.html" class="nav-link">
                     <img src="images/güncelle_fotoğraf.png" alt="">Lastik Bilgi Güncelle
                 </a>
                 
             </li>
             <li class="nav-item">
                 <a href="lastikgoster.php" class="nav-link">
                     <img src="images/göster_fotoğraf.jpg" alt="">Lastik Bilgi Göster
                 </a>
                 
             </li>
             <li class="nav-item">
                 <a href="sil.html" class="nav-link">
                     <img src="images/sil_fotoğraf.jpg" alt="">Lastik Bilgi Sil
                 </a>
                 
             </li>
         </ul>
 </div>


 <div class="sidebar">
     <h2>Sıfır Lastikler</h2>
     <ul>
         <li><a href="yazlastik.html" target="_blank">Yaz</a></li>
         <li><a href="kışlastik.html" target="_blank">Kış</a></li>
         <li><a href="4mevsim.html" target="_blank">4 Mevsim</a></li>           
     </ul>
 </div>

<div class="content">
<div class="table-container">
<?php

 $lkod=$_POST['lkod'];
    
    $baglan=mysqli_connect("localhost","root","","otolastikdunyasi");
    if (!$baglan) {
        die("Bağlantı sağlanamadı: ".mysqli_connect_error());
    }
    echo"<h2>GÜNCELLENEN LASTİK</h2><hr>";
    
    $sonuc=mysqli_query($baglan,"select * from lastik where lkod='$lkod'");
    mysqli_set_charset($baglan, "utf8");

    while($satir=mysqli_fetch_array($sonuc))
    {
    

    echo "<table border='0'>";
    echo "<tr>";
    echo "<td><b>Lastik Kodu</b></td>";
    echo "<td>".$satir['lkod']."</td>";
    echo "</tr>";   
    echo "<tr>";
    echo "<td><b>Lastik Mevsimi</b></td>";
    echo "<td>".$satir['lmevsim']."</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td><b>Lastik Markası</b></td>";
    echo "<td>".$satir['lmarka']. "</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td><b>Lastik Ebatı</b></td>";
    echo "<td>".$satir['lebat']. "</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td><b>Lastik Modeli</b></td>";
    echo "<td>".$satir['lmodel']. "</td>";
    echo "</tr>";
    echo "</table>";
    }

   

?>
</div>

 <div class="adres">
    

 <h2 style="margin-top:7px;">LASTİK BİLGİ GÜNCELLEME</h2>
 <hr>
    
    <form action="bilgiguncelle.php" method="POST" enctype="multipart/form-data">

        <table border="0" style="padding: 5px; border-spacing: 5px;">
            <tr>
                <td><b>Lastik Kodu</b></td>
                <td><input type="text" name="lkod" required placeholder="Lastik kodu giriniz"></td>
            </tr>
            <tr><td><hr style="border: solid;"></td></tr>
            
            <tr>
                <td><b>Lastik Mevsimi</b></td>
                <td>
                   <label for="Yaz">
                    <input type="radio" id="Yaz" name="lmevsim" value="Yaz">
                    Yaz
                </label>
                <label for="Kış">
                    <input type="radio" id="Kış" name="lmevsim" value="Kış">
                    Kış
                </label>
                <label for="4 Mevsim">
                    <input type="radio" id="4 Mevsim" name="lmevsim" value="4 Mevsim">
                    4 Mevsim
                </label> 
                </td>                
            </tr>
            <tr><td><hr style="border: solid;"></td></tr>
            <tr>
                <td><b>Lastik Markası</b></td>
                <td><select id="lmarka" name="lmarka">
                <option value="">Seçiniz</option>
                <option value="CONTINENTAL">CONTINENTAL</option>
                <option value="GOOD YEAR">GOOD YEAR</option>
                <option value="BRIDGESTONE">BRIDGESTONE</option>
                <option value="MICHELIN">MICHELIN</option>
            </td>               
                </select>
            </tr>
            <tr><td><hr style="border: solid;"></td></tr>
            <tr>
                <td><b>Lastik Ebatı</b></td>
                <td><select id="lebat" name="lebat">
                    <option value="">Seçiniz</option>
                    <option value="185/65R 15 88T">185/65R 15 88T</option>
                    <option value="205/55R 16 91V">205/55R 16 91V</option>
                    <option value="245/45R 17 99Y XL">245/45R 17 99Y XL</option>
                    <option value="225/40R 18 92Y XL">225/40R 18 92Y XL</option>
                </td>
            </tr>
            <tr><td><hr style="border: solid;"></td></tr>
            <tr>
                <td><b>Lastik Modeli</b></td>
                <td><input type="text" name="lmodel" required placeholder="Lastik modeli giriniz"></td>                
            </tr>          
            <tr><td><hr style="border: solid;"></td></tr>
            <tr >
                <td colspan="2" style="text-align: end;">               
                    <input type="reset" id="sil" name="sil" value="TEMİZLE">
                    <input type="submit" id="kayit" name="kayit" value="GÜNCELLE">
                </td>
                </tr>
                
        </table>
        
    </form>




</div>

</div>







</body>
</html>