<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>

body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content:flex-start;
            
        }

        .Header{
            display: block;
            background-color: rgb(255, 251, 3);
            color: rgb(25, 30, 184);
            text-align: center;
            font-size: 20px;
        }

        .Menu{
        position: relative;
        background-color: rgb(25, 30, 184);            
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100px;
        font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
        font-size: 30px;
        
        }

    .nav-pills{
        display: flex;
        padding: 0;
        margin: 0;
        align-items: center;
        
        
    }

    .nav-item{
        margin-right: 50px;
        align-items: center;
        
    }

    .nav-link{
        text-decoration: none;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        color: rgb(255, 251, 3);   
    }

img{
width: 50px;
height: 50px; 
border-radius: 50%;
}


.sidebar {
width: 250px;
height: 100vh; 
background-color: #333;
color: white;
padding: 15px;
box-sizing: border-box;
position: fixed; 
left: 0;
top: 201px;
}

.sidebar h2 {
text-align: center;
}

.sidebar ul {
list-style-type: none;
padding: 0;
}

.sidebar ul li {
margin: 15px 0;
}

.sidebar ul li a {
color: white;
text-decoration: none;
display: block;
padding: 10px;
transition: background-color 0.3s;
}

.sidebar ul li a:hover {
background-color: #575757;
}



</style>

</head>
<body>
    

<div class="Header">
           <h1>OTO LASTİK DÜNYASI</h1> 
    </div>

   
    
    <div class="Menu">
            <ul class="nav-pills" style="list-style-type: none;">
                <li class="nav-item">
                    <a href="anasayfa.html" class="nav-link">
                        <img src="images/ana_sayfa_fotograf.png" alt="">Ana Sayfa
                    </a>
                    
                </li>
                <li class="nav-item">
                    <a href="lastik.html" class="nav-link">
                        <img src="images/giriş_fotoğraf.png" alt="">Lastik Bilgi Giriş
                    </a>
                    
                </li>
                <li class="nav-item">
                    <a href="guncelle.html" class="nav-link">
                        <img src="images/güncelle_fotoğraf.png" alt="">Lastik Bilgi Güncelle
                    </a>
                    
                </li>
                <li class="nav-item">
                    <a href="lastikgoster.php" class="nav-link">
                        <img src="images/göster_fotoğraf.jpg" alt="">Lastik Bilgi Göster
                    </a>
                    
                </li>
                <li class="nav-item">
                    <a href="sil.html" class="nav-link">
                        <img src="images/sil_fotoğraf.jpg" alt="">Lastik Bilgi Sil
                    </a>
                    
                </li>
            </ul>
    </div>


    <div class="sidebar">
        <h2>Sıfır Lastikler</h2>
        <ul>
            <li><a href="yazlastik.html" target="_blank">Yaz</a></li>
            <li><a href="kışlastik.html" target="_blank">Kış</a></li>
            <li><a href="4mevsim.html" target="_blank">4 Mevsim</a></li>           
        </ul>
    </div>



    <?php

$sil=$_SESSION['lkod'];

$baglan=mysqli_connect("localhost","root","","otolastikdunyasi");
mysqli_set_charset($baglan, "utf8");
$sonuc=mysqli_query($baglan, "DELETE from lastik where lkod='$sil' ");

if ($sonuc==0){
    echo "<script type='text/javascript'>";
    echo "alert('LASTİK SİLİNEMEDİ');";
    echo "window.location = 'sil.html';"; 
    echo "</script>";}
else{

   echo "<script type='text/javascript'>";
   echo "alert('LASTİK BAŞARIYLA SİLİNDİ');";
   echo "window.location = 'anasayfa.html';"; 
   echo "</script>";
}

?>

</body>
</html>